<?php
// Include the database connection file
require_once 'database_connection.php';

// Check if the form was submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect the form data and sanitize it
    $subject = $_POST['subject'] ?? '';
    $task = $_POST['task'] ?? '';
    $dueDate = $_POST['dueDate'] ?? '';

    // Simple validation to ensure fields are not empty
    if (empty($subject) || empty($task) || empty($dueDate)) {
        // Redirect back to the form with an error message
        header("Location: index.php?error=Please fill in all fields.");
        exit;
    }

    // Use a prepared statement to insert data safely
    $sql = "INSERT INTO tasks (subject, task, due_date) VALUES (?, ?, ?)";
    
    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters to the statement
        $stmt->bind_param("sss", $subject, $task, $dueDate);

        // Execute the statement and check if it was successful
        if ($stmt->execute()) {
            // Success: Redirect with a success message
            header("Location: index.php?success=Task added successfully!");
            exit;
        } else {
            // Error: Redirect with a failure message
            header("Location: index.php?error=Error adding task: " . $stmt->error);
            exit;
        }

        // Close the statement
        $stmt->close();
    } else {
        // Error in preparing the statement
        header("Location: index.php?error=Error preparing statement: " . $conn->error);
        exit;
    }

    // Close the database connection
    $conn->close();
} else {
    // If someone tries to access this page directly without a POST request, redirect them.
    header("Location: index.php");
    exit;
}
?>
