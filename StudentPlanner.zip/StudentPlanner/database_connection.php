<?php
// Database connection credentials
$db_host = "localhost";    // Your database host (often 'localhost')
$db_user = "root"; // Your database username
$db_pass = ""; // Your database password
$db_name = "student_planner"; // The name of your database

// Create a new mysqli connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
