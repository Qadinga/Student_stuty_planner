<?php
// Include the database connection file
require_once 'database_connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Study Planner</title>
    <script src="https://cdn.tailwindcss.com"></script>
    
</head>
<body>
    <div class="container">
        <h1 class="gradient-text">Student Study Planner</h1>
        <form action="process_form.php" method="POST">
            <label for="subject" class="block mb-2 font-medium">Subject</label>
            <input type="text" id="subject" name="subject" class="input-field" placeholder="e.g. Mathematics" required>

            <label for="task" class="block mb-2 font-medium">Task</label>
            <textarea id="task" name="task" class="input-field h-28" placeholder="Describe the study task..." required></textarea>

            <label for="dueDate" class="block mb-2 font-medium">Due Date</label>
            <input type="date" id="dueDate" name="dueDate" class="input-field" required>

            <button type="submit" class="btn-submit">Add To Planner</button>
        </form>

        <div id="taskList" class="mt-8">
            <h2 class="text-xl font-bold mb-4">Current Tasks</h2>
            <?php
            // SQL query to fetch all tasks, ordered by due date
            $sql = "SELECT subject, task, due_date FROM tasks ORDER BY due_date ASC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Loop through each row of the result set
                while($row = $result->fetch_assoc()) {
                    echo "<div class='task-card'>";
                    echo "<h3>" . htmlspecialchars($row['subject']) . "</h3>";
                    echo "<p>" . htmlspecialchars($row['task']) . "</p>";
                    echo "<p class='due-date'>Due: " . htmlspecialchars($row['due_date']) . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p class='text-sm text-gray-400'>No tasks found. Add a new task using the form above.</p>";
            }

            // Close the database connection
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
